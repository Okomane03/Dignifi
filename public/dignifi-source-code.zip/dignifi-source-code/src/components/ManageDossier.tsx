import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  Calendar,
  Clock,
  MapPin,
  Users,
  Paperclip,
  Printer,
  Download,
  Send,
  Plus,
  Trash2,
  FileCheck,
  AlertCircle,
  HelpCircle,
  ArrowLeft,
  CheckCircle2,
} from 'lucide-react';
import { IncidentRecord, SubsequentNote, EvidenceItem } from '../types/incident';
import { generateTrackingToken } from '../utils/crypto';

interface ManageDossierProps {
  record: IncidentRecord;
  onUpdateRecord: (updated: IncidentRecord) => void;
  onDeleteRecord: (id: string) => void;
  onBack: () => void;
  onSubmitToHr: (record: IncidentRecord, isAnonymous: boolean, urgency: 'routine' | 'elevated' | 'critical_safety') => void;
}

export const ManageDossier: React.FC<ManageDossierProps> = ({
  record,
  onUpdateRecord,
  onDeleteRecord,
  onBack,
  onSubmitToHr,
}) => {
  const [newNoteContent, setNewNoteContent] = useState('');
  const [newNoteType, setNewNoteType] = useState<SubsequentNote['noteType']>('additional_recollection');
  
  // Submit to HR modal
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [isAnonymousSubmit, setIsAnonymousSubmit] = useState(false);
  const [urgencySubmit, setUrgencySubmit] = useState<'routine' | 'elevated' | 'critical_safety'>('elevated');

  // CCMA Form viewer state
  const [showCcmaModal, setShowCcmaModal] = useState(false);

  const handleAddSubsequentNote = () => {
    if (!newNoteContent.trim()) return;

    const newNote: SubsequentNote = {
      id: `note-${Date.now()}`,
      timestamp: new Date().toISOString(),
      authorLabel: 'Employee Observation',
      content: newNoteContent.trim(),
      noteType: newNoteType
    };

    const updated: IncidentRecord = {
      ...record,
      updatedAt: new Date().toISOString(),
      subsequentNotes: [...record.subsequentNotes, newNote]
    };

    onUpdateRecord(updated);
    setNewNoteContent('');
  };

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(record, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `dignifi_record_${record.id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const formatCcmaAnnexure = () => {
    return `COMMISSION FOR CONCILIATION, MEDIATION AND ARBITRATION (CCMA)
ANNEXURE TO FORM 7.11 - STATEMENT OF UNFAIR DISCRIMINATION / HARASSMENT / LABOUR DISPUTE
================================================================================
Generated via Dignifi Workplace Dignity OS · Contemporaneous Record Vault
Record ID: ${record.id}
Date Logged: ${new Date(record.createdAt).toLocaleString()}
Digital Integrity Seal (SHA-256): ${record.cryptographicHash}

1. DETAILS OF THE ALLEGED CONDUCT & CONTEXT:
--------------------------------------------------------------------------------
Primary Category: ${record.categories.join(', ')}
Date of Incident: ${record.incidentDate} ${record.incidentTime ? `at ${record.incidentTime}` : ''}
Workplace Context / Location: ${record.locationDetails} (${record.locationType})

2. CONTEMPORANEOUS ACCOUNT OF WHAT OCCURRED:
(Recorded in the employee's own words at or near the time of the event)
--------------------------------------------------------------------------------
"${record.contemporaneousNarrative}"

3. INDIVIDUALS INVOLVED & OBSERVERS:
--------------------------------------------------------------------------------
${record.peopleInvolved.map((p, i) => `[${i + 1}] ${p.nameOrRole} - Role: ${p.roleInIncident} (Seniority: ${p.approximateSeniority})`).join('\n') || 'None recorded.'}

4. PERCEIVED IMPACT ON THE EMPLOYEE:
--------------------------------------------------------------------------------
Psychological & Safety Impact: ${record.perceivedImpact.psychologicalSafety}
Professional & Career Impact: ${record.perceivedImpact.professionalImpact}
Severity Impact Rating: ${record.perceivedImpact.severityScore}/5

5. SUBSEQUENT CHRONOLOGICAL NOTES & OBSERVATIONS:
--------------------------------------------------------------------------------
${record.subsequentNotes.map((n, i) => `[Note ${i + 1} - ${new Date(n.timestamp).toLocaleString()} - Type: ${n.noteType}]\n${n.content}\n`).join('\n') || 'No subsequent amendments logged.'}

6. EVIDENCE ARTIFACTS ATTACHED:
--------------------------------------------------------------------------------
${record.evidenceItems.map((e, i) => `[Artifact ${i + 1}] ${e.title} (${e.type})\nSummary: ${e.summary}\nLocal Checksum: ${e.tamperChecksum}`).join('\n\n') || 'No external files attached.'}

================================================================================
Note: This document was generated from a tamper-evident records vault conforming
to South African Employment Equity Act Code of Good Practice (2022) guidelines.`;
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      
      {/* Top Bar Navigation & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-6 border-b border-[#E2E8DC]">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-[#3C5340] hover:text-[#1C261E] cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Vault</span>
        </button>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-1.5 bg-white border border-[#D5DFD1] hover:bg-[#F2F6EF] text-[#2D4335] text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Dossier (PDF)</span>
          </button>

          <button
            onClick={() => setShowCcmaModal(true)}
            className="px-3.5 py-1.5 bg-[#EAEFE6] hover:bg-[#DFE8DA] text-[#2D4335] text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer"
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>CCMA Form 7.11 Helper</span>
          </button>

          <button
            onClick={handleExportJson}
            className="px-3.5 py-1.5 bg-white border border-[#D5DFD1] hover:bg-[#F2F6EF] text-[#556657] text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>

          {record.status !== 'submitted_to_hr' ? (
            <button
              onClick={() => setShowSubmitModal(true)}
              className="px-4 py-1.5 bg-[#2D4335] hover:bg-[#203126] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Submit to HR</span>
            </button>
          ) : (
            <span className="px-3 py-1 bg-[#E8EFE4] text-[#2D4335] text-xs font-semibold rounded-lg border border-[#D3E0CE] flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#2D4335]" />
              <span>Active HR Case: {record.hrCaseDetails?.trackingToken || record.id}</span>
            </span>
          )}

          <button
            onClick={() => {
              if (confirm('Permanently delete this record and its cryptographic verification? This cannot be undone.')) {
                onDeleteRecord(record.id);
              }
            }}
            className="p-1.5 text-[#964B00] hover:text-[#7A3600] rounded-lg transition-colors cursor-pointer"
            title="Permanently Delete Record"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Record Main Container */}
      <div className="bg-white border border-[#E0E7DC] rounded-2xl p-6 sm:p-8 shadow-xs mb-8">
        
        {/* Title & Core Metadata */}
        <div className="mb-6">
          <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C6E5F] mb-2">
            <span className="font-mono text-[#2D4335] font-bold">{record.id}</span>
            <span aria-hidden="true">·</span>
            <span>Recorded {new Date(record.createdAt).toLocaleDateString()}</span>
            <span aria-hidden="true">·</span>
            <span>Status: {record.status === 'submitted_to_hr' ? 'Submitted to HR Case Desk' : 'Encrypted in Personal Vault'}</span>
          </div>

          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#1C261E] mb-3">
            {record.title}
          </h1>

          <div className="flex flex-wrap items-center gap-3 text-xs text-[#4F6152] bg-[#F7F9F5] p-3 rounded-xl border border-[#EDF2EA]">
            <span><strong>Date Occurred:</strong> {record.incidentDate} {record.incidentTime && `at ${record.incidentTime}`}</span>
            <span aria-hidden="true">·</span>
            <span><strong>Location / Channel:</strong> {record.locationDetails}</span>
            <span aria-hidden="true">·</span>
            <span><strong>Facets:</strong> {record.categories.join(', ')}</span>
          </div>
        </div>

        {/* SECTION 1: CONTEMPORANEOUS FIRST-HAND ACCOUNT (LOCKED & HASHED) */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#2D4335]" />
              <h2 className="text-sm font-bold uppercase tracking-wider text-[#203324]">
                1. Contemporaneous First-Hand Account
              </h2>
            </div>
            <span className="text-[11px] font-mono text-[#586A5A] bg-[#EEF4EC] px-2.5 py-0.5 rounded-full border border-[#DDE7DA]">
              Tamper Hash: {record.cryptographicHash.substring(0, 16)}...
            </span>
          </div>
          <p className="text-[11px] text-[#637565] mb-2.5">
            Preserved exactly as written contemporaneously. This original statement is locked to maintain forensic and labour integrity.
          </p>

          <div className="p-4 bg-[#FAFBF9] border border-[#DEE7DA] rounded-xl text-sm text-[#1C261E] leading-relaxed whitespace-pre-wrap font-sans">
            {record.contemporaneousNarrative}
          </div>
        </div>

        {/* SECTION 2: SUBSEQUENT NOTES & OBSERVATIONS (Strictly Separated) */}
        <div className="mb-8 border-t border-[#EDF2EA] pt-6">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#203324]">
              2. Subsequent Chronological Notes & Updates
            </h2>
            <span className="text-xs text-[#5D6F60]">
              {record.subsequentNotes.length} note{record.subsequentNotes.length === 1 ? '' : 's'} appended
            </span>
          </div>
          <p className="text-[11px] text-[#637565] mb-4">
            Under records-management principles, any new recollections, witness conversations, or retaliation aftermath must be recorded as separate, timestamped additions rather than altering original statements.
          </p>

          {record.subsequentNotes.length > 0 ? (
            <div className="space-y-3 mb-4">
              {record.subsequentNotes.map((note, idx) => (
                <div key={note.id} className="p-3.5 bg-[#F9FAF7] border border-[#DFE7DB] rounded-xl text-xs">
                  <div className="flex items-center justify-between text-[#596B5B] mb-1.5">
                    <span className="font-semibold text-[#203225]">
                      Note #{idx + 1} · {note.noteType.replace('_', ' ')}
                    </span>
                    <span>{new Date(note.timestamp).toLocaleString()}</span>
                  </div>
                  <p className="text-sm text-[#1C261E] leading-relaxed whitespace-pre-wrap">
                    {note.content}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-[#718273] italic mb-4">
              No subsequent notes appended yet. Use the form below to record any new observations.
            </p>
          )}

          {/* Add Subsequent Note Box */}
          <div className="p-4 bg-[#F5F8F2] border border-[#D9E4D4] rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#203225]">
                Append a New Observation or Update
              </label>
              <select
                value={newNoteType}
                onChange={e => setNewNoteType(e.target.value as any)}
                className="text-xs bg-white border border-[#D5DFD1] px-2.5 py-1 rounded-lg text-[#1C261E]"
              >
                <option value="additional_recollection">Additional Recollection</option>
                <option value="witness_conversation">Witness Conversation</option>
                <option value="retaliatory_aftermath">Retaliatory Aftermath / Detriment</option>
                <option value="medical_consultation">Medical / Counseling Consultation</option>
              </select>
            </div>

            <textarea
              rows={3}
              value={newNoteContent}
              onChange={e => setNewNoteContent(e.target.value)}
              placeholder="Record subsequent information with exact time, who you spoke with, or any subsequent adverse workplace reaction..."
              className="w-full px-3 py-2 bg-white border border-[#D5DFD1] rounded-xl text-xs text-[#1C261E] focus:outline-none focus:ring-1 focus:ring-[#2D4335]"
            />

            <div className="flex justify-end">
              <button
                type="button"
                onClick={handleAddSubsequentNote}
                className="px-4 py-2 bg-[#2D4335] hover:bg-[#203126] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Append Note to Record</span>
              </button>
            </div>
          </div>
        </div>

        {/* SECTION 3: PEOPLE INVOLVED & EVIDENCE */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-[#EDF2EA] pt-6 mb-8">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#203324] mb-3">
              Individuals Involved ({record.peopleInvolved.length})
            </h3>
            {record.peopleInvolved.length > 0 ? (
              <div className="space-y-2">
                {record.peopleInvolved.map(person => (
                  <div key={person.id} className="p-2.5 bg-[#FAFBF9] border border-[#E0E8DC] rounded-lg text-xs">
                    <p className="font-semibold text-[#1C261E]">{person.nameOrRole}</p>
                    <div className="flex items-center gap-2 text-[#647566] text-[11px] mt-0.5">
                      <span>Role: {person.roleInIncident.replace('_', ' ')}</span>
                      <span>·</span>
                      <span>Seniority: {person.approximateSeniority?.replace('_', ' ')}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-[#6F8071] italic">No individuals listed.</p>
            )}
          </div>

          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#203324] mb-3">
              Attached Artifacts & Files ({record.evidenceItems.length})
            </h3>
            {record.evidenceItems.length > 0 ? (
              <div className="space-y-2">
                {record.evidenceItems.map(item => (
                  <div key={item.id} className="p-2.5 bg-[#FAFBF9] border border-[#E0E8DC] rounded-lg text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-[#1C261E]">{item.title}</span>
                      <span className="text-[10px] text-[#637465]">({item.type})</span>
                    </div>
                    <p className="text-[11px] text-[#647566] mt-0.5">{item.summary}</p>
                    <p className="font-mono text-[9px] text-[#718273] mt-1">Checksum: {item.tamperChecksum}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-[#6F8071] italic">No evidence files recorded.</p>
            )}
          </div>
        </div>

        {/* SECTION 4: IMPACT STATEMENT & REFLECTION */}
        <div className="border-t border-[#EDF2EA] pt-6">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#203324] mb-3">
            Perceived Impact & Personal Reflection
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3 bg-[#FAFBF9] border border-[#E0E8DC] rounded-xl">
              <span className="font-semibold text-[#203225] block mb-1">Psychological Safety & Wellbeing:</span>
              <p className="text-[#435446]">{record.perceivedImpact.psychologicalSafety}</p>
            </div>
            <div className="p-3 bg-[#FAFBF9] border border-[#E0E8DC] rounded-xl">
              <span className="font-semibold text-[#203225] block mb-1">Professional & Career Impact:</span>
              <p className="text-[#435446]">{record.perceivedImpact.professionalImpact}</p>
            </div>
          </div>
        </div>

        {/* If this record has active HR Case Status, show HR updates */}
        {record.hrCaseDetails && (
          <div className="mt-8 border-t border-[#DFE7DB] pt-6 bg-[#F6F9F3] p-5 rounded-2xl border">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#2D4335]" />
                <h3 className="text-sm font-bold text-[#1C261E]">
                  HR Case Tracking Portal ({record.hrCaseDetails.trackingToken})
                </h3>
              </div>
              <span className="text-xs font-semibold text-[#2D4335] bg-[#E3EDE0] px-2.5 py-1 rounded-md">
                Status: {record.hrCaseDetails.hrStatus.replace('_', ' ')}
              </span>
            </div>

            <p className="text-xs text-[#556757] mb-4">
              Assigned Lead: <strong>{record.hrCaseDetails.assignedOfficer}</strong> · Submitted: {new Date(record.hrCaseDetails.submittedAt).toLocaleDateString()}
            </p>

            {record.hrCaseDetails.secureNotesToEmployee && record.hrCaseDetails.secureNotesToEmployee.length > 0 && (
              <div className="space-y-2 mb-4">
                <label className="text-xs font-semibold text-[#203225]">Messages from HR Case Officer:</label>
                {record.hrCaseDetails.secureNotesToEmployee.map((msg, i) => (
                  <div key={i} className="p-3 bg-white border border-[#D5DFD1] rounded-xl text-xs">
                    <div className="flex justify-between text-[#687869] mb-1 text-[11px]">
                      <span className="font-semibold text-[#1C261E]">{msg.officer}</span>
                      <span>{new Date(msg.timestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-sm text-[#1C261E] leading-relaxed">{msg.message}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>

      {/* MODAL: SUBMIT TO HR */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#D6DFD2] rounded-2xl p-6 max-w-lg w-full shadow-2xl space-y-5 animate-in fade-in duration-150">
            <div>
              <h3 className="font-serif text-xl font-bold text-[#1C261E]">
                Package & Submit Incident to HR
              </h3>
              <p className="text-xs text-[#5D6F60] mt-1">
                Submitting creates an encrypted transmission directly to the HR Case Officer portal. You retain your local master copy.
              </p>
            </div>

            <div className="space-y-4 text-xs">
              
              {/* Anonymity Option */}
              <div className="p-3.5 bg-[#FAFBF9] border border-[#E0E7DC] rounded-xl">
                <label className="flex items-center gap-2 cursor-pointer font-semibold text-[#1C261E]">
                  <input
                    type="checkbox"
                    checked={isAnonymousSubmit}
                    onChange={e => setIsAnonymousSubmit(e.target.checked)}
                    className="rounded text-[#2D4335] focus:ring-[#2D4335]"
                  />
                  <span>Submit Anonymously</span>
                </label>
                <p className="text-[11px] text-[#657667] mt-1 ml-5">
                  Your identity and name will be stripped from the dossier. You will receive a unique tracking token (e.g. DIG-8921-X) to monitor HR updates privately.
                </p>
              </div>

              {/* Urgency Level */}
              <div>
                <label className="block font-semibold text-[#1C261E] mb-1.5">
                  Triage Urgency Tier
                </label>
                <select
                  value={urgencySubmit}
                  onChange={e => setUrgencySubmit(e.target.value as any)}
                  className="w-full px-3 py-2 bg-[#FAFBF9] border border-[#D5DFD1] rounded-xl text-xs text-[#1C261E]"
                >
                  <option value="routine">Routine: Review within 5 business days</option>
                  <option value="elevated">Elevated: Immediate review (Harassment / Retaliation risks)</option>
                  <option value="critical_safety">Critical: Imminent safety hazard / Physical GBV crisis</option>
                </select>
              </div>

              <div className="p-3 bg-[#F4F7F1] border border-[#DDE7DA] rounded-xl text-[11px] text-[#445849]">
                <strong>South African Labour Law Note:</strong> Submitting formal notice to HR triggers your employer's legal duty under Section 60 of the Employment Equity Act to eliminate harassment and investigate without victimizing the reporting employee.
              </div>
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                onClick={() => setShowSubmitModal(false)}
                className="px-4 py-2 text-xs font-semibold text-[#5A6C5D] hover:text-[#1C261E] cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onSubmitToHr(record, isAnonymousSubmit, urgencySubmit);
                  setShowSubmitModal(false);
                }}
                className="px-5 py-2 bg-[#2D4335] hover:bg-[#203126] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Confirm Encrypted Submission</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CCMA FORM 7.11 HELPER */}
      {showCcmaModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#D6DFD2] rounded-2xl p-6 max-w-2xl w-full shadow-2xl space-y-4 max-h-[85vh] flex flex-col animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-serif text-lg font-bold text-[#1C261E]">
                  CCMA Form 7.11 Evidentiary Annexure Draft
                </h3>
                <p className="text-xs text-[#5D6F60]">
                  Pre-formatted text compliant with CCMA dispute referral requirements in South Africa.
                </p>
              </div>
              <button
                onClick={() => setShowCcmaModal(false)}
                className="text-xs font-semibold text-[#596B5C] hover:text-[#1C261E]"
              >
                Close
              </button>
            </div>

            <textarea
              readOnly
              value={formatCcmaAnnexure()}
              className="w-full flex-1 p-3 bg-[#FAFBF9] border border-[#D5DFD1] rounded-xl font-mono text-xs text-[#1C261E] focus:outline-none min-h-[300px]"
            />

            <div className="flex justify-between items-center pt-2">
              <span className="text-[11px] text-[#697A6B]">
                Copy this text to paste into Annexure Section 4 of CCMA Form 7.11.
              </span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(formatCcmaAnnexure());
                  alert('CCMA Annexure text copied to clipboard!');
                }}
                className="px-4 py-2 bg-[#2D4335] hover:bg-[#203126] text-white text-xs font-semibold rounded-xl cursor-pointer"
              >
                Copy to Clipboard
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
